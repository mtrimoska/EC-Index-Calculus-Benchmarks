#ifndef weil_h
#define weil_h

#include <stdio.h>
#include "vect_bin.h"

void create_weil(_vect_bin_t *f, int *constant, char *irr, char *Xr, char *solution, int nb_terms);


#endif /* weil_h */
