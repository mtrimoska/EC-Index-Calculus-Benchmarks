int new_offset = 343;
